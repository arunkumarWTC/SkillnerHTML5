
1. Install [stylus](http://learnboost.github.com/stylus/)
2. cd ./player && make playful # or minimalist / functional
3. open test/index.html
4. modify stylus files and/or index.html modifier classes and reload the browser
